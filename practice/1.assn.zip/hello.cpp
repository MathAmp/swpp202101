#include <iostream>
using namespace std;

int main() {
  cout << "Hello, my name is mathamp" << endl;
  return 0;
}
